
#ifndef __AGC_PLANC_H
#define __AGC_PLANC_H

#include <vector>
#include "common.h"
#include "linkedlist.hpp"

typedef enum _AGC_MARK_STATE
{
	/// <summary>
	/// Not marked
	/// </summary>
	AGC_MARK_WHITE,
	/// <summary>
	/// Was marked, but was referenced by a white object
	/// </summary>
	AGC_MARK_GRAY,
	/// <summary>
	/// Marked
	/// </summary>
	AGC_MARK_BLACK
}
AGC_MARK_STATE;

struct GCRecord
{
	AGC_MARK_STATE markState;
	void *ptr;
	// Pointers pointed from here
	std::vector<GCRecord *> *references_out;
	// Pointers pointed to here
	std::vector<GCRecord *> *references_in;
	asize_t allocatedSize;
	unsigned long classID;

	GCRecord();
	~GCRecord();
};

class PlanC
{

public:

	static void Initialize();
	static void Uninitialize();
	static void InitializeL();
	static void UninitializeL();

	static void Collect();
	static void CollectL();

	static void *AllocHeap(asize_t size);
	static void *AllocGlobal(asize_t size);
	static void *AllocHeapL(asize_t size);
	static void *AllocGlobalL(asize_t size);

private:

	static void Mark();
	static void Sweep();
	static void MarkL();
	static void SweepL();

};

#endif
