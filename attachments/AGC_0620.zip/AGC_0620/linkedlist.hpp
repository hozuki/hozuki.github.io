
#ifndef __AGC_LINKEDLIST_H
#define __AGC_LINKEDLIST_H

#include <cstdlib>
#include <cstring>

template<class T> class linkedlist
{

public:

	typedef struct _listnode
	{
		_listnode *prev, *next;
		T data;

		_listnode()
		{
			prev = next = NULL;
			memset(&data, 0, sizeof(T));
		}
	} listnode;

private:

	listnode *head, *tail;
	unsigned int count;

public:

	linkedlist()
	{
		head = tail = NULL;
		count = 0;
	}

	~linkedlist()
	{
		listnode *p = head, *p2 = NULL;
		while (p)
		{
			p2 = p->next;
			delete p;
			p = p2;
		}
	}

	static linkedlist *create()
	{
		return new linkedlist<T>();
	}

	static void dispose(linkedlist<T> *&plist)
	{
		if (plist)
		{
			delete plist;
		}
	}

public:

	void push_back(T data)
	{
		listnode *n;
		n = new listnode();
		n->data = data;
		n->prev = tail;
		n->next = NULL;
		if (tail)
		{
			tail->next = n;
		}
		else
		{
			head = n;
		}
		tail = n;
		count++;
	}

	void pop_back()
	{
		if (tail)
		{
			listnode *n = tail->prev;
			delete tail;
			tail = n;
			if (n == NULL)
			{
				head = NULL;
			}
			else
			{
				n->next = NULL;
			}
			count--;
		}
	}

	void push_front(T data)
	{
		listnode *n;
		n->data = data;
		n->next = head;
		n->prev = NULL;
		if (head)
		{
			head->prev = n;
		}
		else
		{
			tail = n;
		}
		head = n;
		count++;
	}

	void pop_front()
	{
		if (head)
		{
			listnode *n = head->next;
			delete head;
			head = n;
			if (n == NULL)
			{
				tail = NULL;
			}
			else
			{
				n->prev = NULL;
			}
			count--;
		}
	}

	static void delete_node(linkedlist<T> *l, listnode *pn)
	{
		if (pn->prev)
		{
			pn->prev->next = pn->next;
		}
		else
		{
			l->head = pn->next;
			if (pn->next)
			{
				pn->next->prev = NULL;
			}
		}
		if (pn->next)
		{
			pn->next->prev = pn->prev;
		}
		else
		{
			l->tail = pn->prev;
			if (pn->prev)
			{
				pn->prev->next = NULL;
			}
		}
		delete pn;
	}

	unsigned int size()
	{
		return count;
	}

	listnode *front()
	{
		return head;
	}

	listnode *end()
	{
		return tail;
	}

};

#endif
