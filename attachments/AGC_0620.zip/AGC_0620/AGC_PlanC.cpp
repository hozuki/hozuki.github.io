
#include <queue>
#include <stack>
#include <vector>
#include <cstdlib>
#include <list>

#include "AGC_PlanC.h"

using namespace std;

inline void ClearVector(vector<GCRecord *> &v)
{
	vector<GCRecord *>(v).swap(v);
}

void AA()
{
}

vector<GCRecord *> *m_pAllObjects;
vector<GCRecord *> *m_pGlobalSet;
vector<GCRecord *> *m_pRuntimeStack;
linkedlist<GCRecord *> *m_pGlobals = NULL;

asize_t m_uAllocatedSize = 0;
asize_t m_uAllocationThreshold = 2 * 1024 * 1024 * 1024;

void Cleanup()
{
	for (auto iter : *m_pAllObjects)
	{
		delete static_cast<GCRecord *>(iter);
	}
	ClearVector(*m_pAllObjects);
}

void CleanupL()
{
}

GCRecord::GCRecord()
{
	this->references_in = new std::vector<GCRecord *>();
	this->references_out = new std::vector<GCRecord *>();
	this->markState = AGC_MARK_WHITE;
	this->allocatedSize = 0;
	this->ptr = NULL;
	this->classID = 0;
}

GCRecord::~GCRecord()
{
	for (auto r : *references_in)
	{
		// clearvector()
		delete static_cast<GCRecord *>(r);
	}
	// destructor = find_destructor_by_classid(this->classID);
	// destructor(this->ptr)
	free(this->ptr);
	delete references_out;
	delete references_in;
}

void PlanC::Initialize()
{
	m_pAllObjects = new vector<GCRecord *>();
	m_pGlobalSet = new vector<GCRecord *>();
	m_pRuntimeStack = new vector<GCRecord *>();
	m_pAllObjects->reserve(65536);
}

void PlanC::InitializeL()
{
	m_pGlobals = new linkedlist<GCRecord *>();
}

void PlanC::Uninitialize()
{
	Cleanup();
	delete m_pRuntimeStack;
	delete m_pGlobalSet;
	delete m_pAllObjects;
}

void PlanC::UninitializeL()
{
	CleanupL();
	delete m_pGlobals;
}

void PlanC::Mark()
{
	queue<GCRecord *> records;
	for (auto iter : *m_pGlobalSet)
	{
		if (iter)
		{
			records.push(iter);
		}
	}
	for (auto iter : *m_pRuntimeStack)
	{
		if (iter)
		{
			records.push(iter);
		}
	}

	asize_t xs = records.size();
	while (xs > 0)
	{
		GCRecord *rec = records.front();
		rec->markState = AGC_MARK_BLACK;
		records.pop();
		xs--;
		for (auto r2 : *rec->references_out)
		{
			if (r2->markState != AGC_MARK_BLACK) // including white and gray
			{
				records.push(r2);
				xs++;
			}
		}
	}
}

void PlanC::MarkL()
{
	queue<GCRecord *> records;
	//for (auto p = m_pGlobals->front(); p != NULL; p = p->next)
	//{
	//	records.push(p->data);
	//}

	asize_t xs = records.size();
	while (xs > 0)
	{
		GCRecord *rec = records.front();
		rec->markState = AGC_MARK_BLACK;
		records.pop();
		xs--;
		for (auto r2 : *rec->references_out)
		{
			if (r2->markState != AGC_MARK_BLACK) // including white and gray
			{
				records.push(r2);
				xs++;
			}
		}
	}
}

void PlanC::Sweep()
{
	GCRecord *p;
	unsigned int c = m_pAllObjects->size();
	for (auto iter = m_pAllObjects->begin(); c > 0;)
	{
		if (*iter)
		{
			if ((*iter)->markState == AGC_MARK_WHITE)
			{
				p = static_cast<GCRecord *>(*iter); // Needed. void * does not invoke any type destructor.
				//delete *iter;
				m_uAllocatedSize -= p->allocatedSize;
				delete p;
				iter = m_pAllObjects->erase(iter);
				c--;
			}
			else
			{
				// You cannot invoke iter++ in for-loop since after deletion the iterator is invalid.
				// http://blog.csdn.net/yang3wei/article/details/7589344
				iter++;
				c--;
			}
		}
		else
		{
		}
	}
}

void PlanC::SweepL()
{
	GCRecord *p;
	linkedlist<GCRecord *>::listnode *pn;
	for (auto pr = m_pGlobals->front(); pr != NULL;)
	{
		if (pr->data->markState == AGC_MARK_WHITE)
		{
			pn = pr->next;
			p = pr->data; // Needed. void * does not invoke any type destructor.
			//delete *iter;
			m_uAllocatedSize -= p->allocatedSize;
			delete p;
			linkedlist<GCRecord *>::delete_node(m_pGlobals, pr);
			pr = pn;
		}
		else
		{
			pr = pr->next;
		}
	}
}

void PlanC::Collect()
{
	PlanC::Mark();
	PlanC::Sweep();
	// http://www.cnblogs.com/viviman/archive/2012/10/29/2775104.html
	//vector<GCRecord *>(*m_pAllObjects).swap(*m_pAllObjects);
	//m_pAllObjects->shrink_to_fit();
	ClearVector(*m_pAllObjects);
}

void PlanC::CollectL()
{
	MarkL();
	SweepL();
}

void *PlanC::AllocGlobal(asize_t size)
{
	m_uAllocatedSize += size;
	if (m_uAllocatedSize > m_uAllocationThreshold)
		Collect();

	auto p = malloc(size);
	if (p)
	{
		GCRecord *rec = new GCRecord();
		rec->ptr = p;
		rec->allocatedSize = size;
		m_pAllObjects->push_back(rec);
		m_pGlobalSet->push_back(rec);
		m_uAllocatedSize += size;
		return p;
	}
	else
	{
		//throw new OutOfMemoryException();
		return NULL;
	}
}

void *PlanC::AllocHeap(asize_t size)
{
	m_uAllocatedSize += size;
	if (m_uAllocatedSize > m_uAllocationThreshold)
		Collect();

	auto p = malloc(size);
	if (p)
	{
		GCRecord *rec = new GCRecord();
		rec->ptr = p;
		rec->allocatedSize = size;
		m_pAllObjects->push_back(rec);
		return p;
	}
	else
	{
		//throw new OutOfMemoryException();
		return NULL;
	}
}

void *PlanC::AllocHeapL(asize_t size)
{
	m_uAllocatedSize += size;
	if (m_uAllocatedSize > m_uAllocationThreshold)
		CollectL();

	auto p = malloc(size);
	if (p)
	{
		GCRecord *rec = new GCRecord();
		rec->ptr = p;
		rec->allocatedSize = size;
		m_pGlobals->push_back(rec);
		return p;
	}
	else
	{
		//throw new OutOfMemoryException();
		return NULL;
	}
}
