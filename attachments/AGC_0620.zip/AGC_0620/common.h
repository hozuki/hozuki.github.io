
#ifndef __HOZUKI_COMMON_H
#define __HOZUKI_COMMON_H

#ifndef NULL
#define NULL (0)
#endif

#define NAMESPACE_START(name) namespace name {
#define NAMESPACE_END(name) }

typedef unsigned int asize_t;
typedef long atypeid_t;
typedef unsigned char a_u8;
typedef void * ptr;

#endif
